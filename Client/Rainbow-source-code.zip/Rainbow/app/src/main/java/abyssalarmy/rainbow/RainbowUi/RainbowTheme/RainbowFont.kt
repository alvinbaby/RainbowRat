package abyssalarmy.rainbow.RainbowUi.RainbowTheme

import abyssalarmy.rainbow.R
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily

val RainbowFont = FontFamily(Font(R.font.outfit))