import abyssalarmy.rainbow.RainbowAccessibilityService
import abyssalarmy.rainbow.RainbowViewModel
import androidx.compose.runtime.Composable

@Composable
fun RainbowAccessibility(rainbowViewModel: RainbowViewModel) {

}